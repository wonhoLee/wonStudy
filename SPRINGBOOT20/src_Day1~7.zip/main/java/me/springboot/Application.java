package me.springboot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ExitCodeGenerator;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
//@ComponentScan
//@Configuration
//@Import(ServiceConfig.class)
//@ImportResource("application.xml")
public class Application {

    @Bean
    public ExitCodeGenerator exitCodeGenerator(){
        return () -> 42;
    }

    public static void main(String[] args){
        /*SpringApplication springApplication = new SpringApplication(Application.class);
        //springApplication.setBanner(new MyBanner());
        springApplication.addListeners(new MyListener());
        springApplication.run(args);*/

        System.exit(SpringApplication.exit(SpringApplication.run(Application.class, args)));

        //SpringApplication.run(Application.class, args);
    }

}

/*
application.xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xsi:schemaLocation="
        http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd">

    <bean id="userService" class="me.springboot.user.UserService" />

</beans>
 */