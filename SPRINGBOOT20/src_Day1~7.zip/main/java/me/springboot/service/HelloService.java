package me.springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/*
 *  @author wonho
 */
@Service
public class HelloService {
    @Autowired
    ApplicationArguments arguments;

    /*@Value("${hello}")
    String[] helloValues;*/

    /*
    --hello=Hello --hello=world
     */
    public String getMessage(){
        /*List<String> helloValues = arguments.getOptionValues("hello");
        return helloValues.stream().collect(Collectors.joining(","));*/
        return "Hello Spring Boot!!";
    }

    public String getMessage2(){
        //return Arrays.stream(helloValues).collect(Collectors.joining(","));
        return "Hello Spring Boot!!";
    }

    /*@PostConstruct
    public void init(){
        throw new RuntimeException("Intended Exception");
    }*/
}
