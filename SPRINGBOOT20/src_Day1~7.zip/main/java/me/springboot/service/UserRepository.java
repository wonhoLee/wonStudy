package me.springboot.service;

import org.springframework.stereotype.Repository;

/*
 *  @author wonho
 */
@Repository
public class UserRepository {
}
