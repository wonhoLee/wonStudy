package me.docu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourseDocuApplication {

	public static void main(String[] args) {
		SpringApplication.run(CourseDocuApplication.class, args);
	}
}
